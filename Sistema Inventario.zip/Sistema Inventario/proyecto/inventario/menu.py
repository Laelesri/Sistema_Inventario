import os

from inventario.crud import *

def menu():
    while True:
        os.system("cls")
        print("*** Gestión de Inventario ***")
        print("1. Agregar Stock a Producto")
        print("2. Restar Stock de Producto")
        print("3. Consultar Stock de Producto")
        print("4. Generar Reporte de Inventario")
        print("5. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            agregar_stock_producto()
        elif opcion == "2":
            restar_stock_producto()
        elif opcion == "3":
            consultar_stock_producto()
        elif opcion == "4":
            generar_reporte_inventario()
        elif opcion == "5":
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            input("Presione Enter para continuar ...")

