import os
from general import funciones as fnc
import csv
    
kardex = {}

def existe_documento(archivo_csv, documento):
    if os.path.exists(archivo_csv):
        with open(archivo_csv, "r", encoding="utf-8") as archivo:
            reader = csv.DictReader(archivo, delimiter="|")
            registros = list(reader)

        existe = next((reg for reg in registros if reg["documento"] == documento), None)
        return existe
    return None

def agregar_stock_producto():
    os.system("cls")
    print("*** Agregar Stock a Producto ***\n")
    codigo = input("Ingrese el código del producto: ").strip()

    if codigo in kardex:
        cantidad = fnc.getEntero("Ingrese la cantidad a agregar: ")
        kardex[codigo]['cantidad'] += cantidad
        print(f"Se han agregado {cantidad} unidades al producto {kardex[codigo]['nombre']}.")
    else:
        nombre = input("Ingrese el nombre del nuevo producto: ").strip()
        cantidad = fnc.getEntero("Ingrese la cantidad del nuevo producto: ")
        precio = fnc.getFlotante("Ingrese el precio del nuevo producto: ")

        kardex[codigo] = {
            'nombre': nombre,
            'cantidad': cantidad,
            'precio': precio
        }
        print(f"Producto {nombre} agregado al kardex con código {codigo}.")

    fnc.getLetra("Presione S para continuar ...", "S")

def restar_stock_producto():
    os.system("cls")
    print("*** Restar Stock de Producto ***\n")
    codigo = input("Ingrese el código del producto: ").strip()

    if codigo in kardex:
        cantidad = fnc.getEntero("Ingrese la cantidad a restar: ")
        if cantidad <= kardex[codigo]['cantidad']:
            kardex[codigo]['cantidad'] -= cantidad
            print(f"Se han restado {cantidad} unidades del producto {kardex[codigo]['nombre']}.")
        else:
            print("No hay suficiente stock para restar esa cantidad.")
    else:
        print("Producto no encontrado en el kardex.")

    fnc.getLetra("Presione S para continuar ...", "S")

def consultar_stock_producto():
    os.system("cls")
    print("*** Consultar Stock de Producto ***\n")
    codigo = input("Ingrese el código del producto (o deje en blanco para listar todos): ").strip()

    if codigo == "":
        if not kardex:
            print("No hay productos en el kardex.")
        else:
            print("Listado de Productos en el Kardex:")
            for codigo, producto in kardex.items():
                print(f"ID: {codigo}, Nombre: {producto['nombre']}, Cantidad: {producto['cantidad']}, Precio: {producto['precio']:.2f}")
    elif codigo in kardex:
        producto = kardex[codigo]
        print(f"ID: {codigo}\nNombre: {producto['nombre']}\nCantidad: {producto['cantidad']}\nPrecio: {producto['precio']:.2f}")
    else:
        print("Producto no encontrado en el kardex.")

    fnc.getLetra("Presione S para continuar ...", "S")

def generar_reporte_inventario():
    os.system("cls")
    print("*** Reporte de Inventario ***\n")
    if not kardex:
        print("No hay productos en el kardex.")
    else:
        for codigo, producto in kardex.items():
            if producto['cantidad'] < 10:  
                print(f"ID: {codigo}, Nombre: {producto['nombre']}, Cantidad: {producto['cantidad']}")

    fnc.getLetra("Presione S para continuar ...", "S")

