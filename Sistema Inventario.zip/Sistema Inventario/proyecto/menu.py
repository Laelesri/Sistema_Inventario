import os

import cliente.menu as cliente
import producto.menu as producto
import inventario.menu as inventario
import facturacion.menu as facturacion

from general.funciones import *

def menu():
    salir = True
    while salir:
        os.system("cls")
        print("***Sistema de Facturación***")    
        print()
        print("1. Gestión de Clientes")
        print("2. Gestión de Productos")
        print("3. Gestión de Inventario")
        print("4. Facturación")
        print("5. Salir")
        print()

        opcion = getOpcion("Digite el # de opcion: ")

        if opcion == 1:
            cliente.menu()
        elif opcion == 2:
            producto.menu()
        elif opcion == 3:
            inventario.menu()
        elif opcion == 4:
            facturacion.menu()
        elif opcion == 5:
            salir = False
        else:
            print("Opción incorrecta.!")
    else:
        print()
        print("Gracias por utilizar nuestro sistema.")

menu()