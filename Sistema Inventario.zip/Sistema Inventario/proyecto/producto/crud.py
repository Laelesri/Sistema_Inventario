import os
import csv

productos = []

def existe_documento(archivo_csv, codigo):
    if os.path.exists(archivo_csv):
        with open(archivo_csv, "r", encoding="utf-8") as archivo:
            reader = csv.DictReader(archivo, delimiter="|")
            registros = list(reader)

        existe = next((reg for reg in registros if reg["codigo"] == codigo), None)
        return existe
    return None

def crearProducto():
    os.system("cls")
    print("*** Creación de Producto ***")
    print()
    
    codigo = input("Ingrese el código del producto: ")
    if existe_documento("productos.csv", codigo):
        print("El código ya existe. Intente con otro.")
        return False

    nombre = input("Ingrese el nombre del producto: ")
    descripcion = input("Ingrese la descripción del producto: ")
    precio = float(input("Ingrese el precio del producto: "))

    nuevo_producto = {
        "id": len(productos) + 1,
        "codigo": codigo,
        "nombre": nombre,
        "descripcion": descripcion,
        "precio": precio
    }

    productos.append(nuevo_producto)
    print(f"Producto {nombre} agregado con éxito.")
    input("Presione Enter para continuar ...")
    return True

def consultarProducto():
    os.system("cls")
    print("*** Consulta de Producto ***")
    print()
    busqueda = input("Ingrese el código o nombre del producto: ")
    
    encontrado = False  

    for producto in productos:
        if producto['codigo'] == busqueda or producto['nombre'].lower() == busqueda.lower():
            print()
            print(f"ID: {producto['id']}")
            print(f"Código: {producto['codigo']}")
            print(f"Nombre: {producto['nombre']}")
            print(f"Descripción: {producto['descripcion']}")
            print(f"Precio: {producto['precio']:.2f}")
            encontrado = True
            break  
    
    if not encontrado:
        print("Producto no encontrado.")

    input("Presione Enter para continuar ...")
    return None

def actualizarProducto():
    os.system("cls")
    print("*** Actualizar Producto ***")
    print()
    busqueda = input("Ingrese el código del producto a actualizar: ")

    for producto in productos:
        if producto['codigo'] == busqueda:
            print(f"Producto encontrado: {producto['nombre']}")
            nuevo_nombre = input("Ingrese el nuevo nombre del producto (deje vacío para no cambiar): ")
            nuevo_descripcion = input("Ingrese la nueva descripción (deje vacío para no cambiar): ")
            nuevo_precio = input("Ingrese el nuevo precio (deje vacío para no cambiar): ")

            if nuevo_nombre:
                producto['nombre'] = nuevo_nombre
            if nuevo_descripcion:
                producto['descripcion'] = nuevo_descripcion
            if nuevo_precio:
                producto['precio'] = float(nuevo_precio)

            print("Producto actualizado con éxito.")
            break
    else:
        print("Producto no encontrado.")

    input("Presione Enter para continuar ...")
    return None

def eliminarProducto():
    os.system("cls")
    print("*** Eliminar Producto ***")
    print()
    busqueda = input("Ingrese el código del producto a eliminar: ")

    for i, producto in enumerate(productos):
        if producto['codigo'] == busqueda:
            del productos[i]
            print("Producto eliminado con éxito.")
            break
    else:
        print("Producto no encontrado.")

    input("Presione Enter para continuar ...")
    return None

def listarProductos():
    os.system("cls")
    print("*** Listar Productos ***")
    print()
    
    if not productos:
        print("No hay productos disponibles.")
    else:
        for producto in productos:
            print(f"ID: {producto['id']}, Código: {producto['codigo']}, Nombre: {producto['nombre']}, Precio: {producto['precio']:.2f}")
    
    input("Presione Enter para continuar ...")
    return None