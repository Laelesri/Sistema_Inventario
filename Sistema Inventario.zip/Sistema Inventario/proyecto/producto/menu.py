import os
from producto.crud import *

def menu():
    while True:
        os.system("cls")
        print("*** Gestión de Productos ***")
        print("1. Crear Producto")
        print("2. Consultar Producto")
        print("3. Actualizar Producto")
        print("4. Eliminar Producto")
        print("5. Listar Productos")
        print("6. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            crearProducto()
        elif opcion == "2":
            consultarProducto()
        elif opcion == "3":
            actualizarProducto()
        elif opcion == "4":
            eliminarProducto()
        elif opcion == "5":
            listarProductos()
        elif opcion == "6":
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            input("Presione Enter para continuar ...")


