import os
from general.funciones import *
from cliente.crud import *

def menu():
    while True:
        os.system("cls")
        print("***Gestión de Clientes***")
        print()
        print("1. Crear Cliente")
        print("2. Modificar Cliente")
        print("3. Consultar Cliente")
        print("4. Eliminar Cliente")
        print("5. Listar Clientes")
        print("6. Volver al menú principal")
        print()

        opcion = getOpcion("Digite el # de opcion: ")

        if opcion == 1:
            crearCliente()
        elif opcion == 2:
            modificarCliente()
        elif opcion == 3:
            cliente = consultarCliente()
            if cliente:
                getLetra("presione S para continuar.","S")
            else:
                getLetra("Cliente no encontrado, presione S para continuar.","S")
        elif opcion == 4:
            eliminarCliente()
        elif opcion == 5:
            listarClientes()
        elif opcion == 6:
            return True
        else:
            print("Opción incorrecta.!")