import os
from general import funciones as fnc
import csv
registros=[]

def existeDocumento(archivo_csv,documento):
    global registros
    if os.path.exists(archivo_csv):
        with open(archivo_csv,"r",encoding="utf-8") as archivo:
            reader = csv.DictReader(archivo,delimiter="|")
            registros = list(reader)

        existe = next((reg for reg in registros if reg["documento"] == documento), None)

        return existe
    else:
        return None

def crearCliente():
    archivo_csv = 'cliente.csv'
    os.system("cls")
    print("***Creación de Cliente***")
    print()
    tipoDocumento = fnc.getLetra("Ingrese el tipo de documento R(RUC) ó C(Cédula): ","R,C")

    tipoDocumentoStr = "RUC" if tipoDocumento == "R"  else "Cédula"
    largo = 13 if tipoDocumento == "R"  else 10
    while True:
        documento = fnc.getStringNumerico(f"Digite su {tipoDocumentoStr}: ",largo)
        if largo == 13:
            if not existeDocumento(archivo_csv,documento):
                break
            else:
                print("Ruc ya existe...")
        elif fnc.validarCedula(documento)[0] == False:
            print(fnc.validarCedula(documento)[1])
        else:
            if not existeDocumento(archivo_csv,documento):
                break
            else:
                print("Cédula ya existe...")
    
    nombre = fnc.getString("Ingrese su Nombre y Apellido: ")
    telefono = fnc.getStringNumerico(f"Digite su número celular: ",10)
    correo = fnc.getCorreo("Ingrese su correo: ")
    direccion  = input("Ingrese su dirección de domicilio: ")

    try:       

        if os.path.exists(archivo_csv):
            with open(archivo_csv,"r",encoding="utf-8") as archivo:
                reader = csv.DictReader(archivo,delimiter="|")
                registros = list(reader)


            existe = next((True for reg in registros if reg["documento"] == documento), False)

            id = len(registros) + 1
        else:
            id = 1
        
        nuevo_cliente = {
            "id" : id,
            "tipoDocumento" : tipoDocumento,
            "documento" : documento,
            "nombre" : nombre,
            "telefono" : telefono,
            "correo" : correo,
            "direccion" : direccion
        }
   
        with open(archivo_csv,"a+",encoding="utf-8", newline='') as archivo:
            fieldnames = nuevo_cliente.keys()
            writer = csv.DictWriter(archivo, fieldnames=fieldnames, delimiter='|')
    
            if id == 1:
                 writer.writeheader()
            writer.writerow(nuevo_cliente)

        print(f"Cliente {nombre} agregado con éxito")
        fnc.getLetra("Presione S para continuar ...","S")
        return True
    except Exception as e:
        fnc.getLetra(f"Error {e}, Presione S para continuar ...","S")
        return False

def modificarCliente():
    global registros
    cliente = consultarCliente()

    if not cliente:
        fnc.getLetra("No se pudo modificar el cliente, prsione S para continuar ...","S")
    else:
        print("***Modificar Cliente***")
        print()
        nombre = fnc.getString("Ingrese su Nombre y Apeliido: ") or cliente['nombre']
        telefono = fnc.getStringNumerico(f"Digite su número celular: ",10) or cliente['telefono']
        correo = fnc.getCorreo("Ingrese su correo: ") or cliente['correo']
        direccion  = input("Ingrese su dirección de domicilio: ") or cliente['direccion']

        cliente.update({
            "nombre" : nombre,
            "telefono" : telefono,
            "correo" : correo,
            "direccion" : direccion
        })

        try:
            with open("cliente.csv","w",encoding="utf-8", newline='') as archivo:
                fieldnames =  registros[0].keys()
                writer =  csv.DictWriter(archivo, fieldnames=fieldnames, delimiter="|")
                writer.writeheader()
                writer.writerows(registros)

        except Exception as e:
            print(f"Error {e}")


        fnc.getLetra("Cliente modificado, presione S para continuar ...","S")
        


def consultarCliente():
    os.system("cls")
    print("***Consulta de Cliente***")
    print()
    busqueda  = input("Ingrese el nombre, RUC, Cédula o ID del cliente: ")
    cliente = existeDocumento("cliente.csv", busqueda)

    if not cliente:
        return None
    else:
        print()
        print(f"ID: {cliente['id']}")
        print(f"Tipo Documento: {cliente['tipoDocumento']}")
        print(f"# Documento: {cliente['documento']}")
        print(f"Nombre: {cliente['nombre']}")
        print(f"Teléfono: {cliente['telefono']}")
        print(f"Correo: {cliente['correo']}")
        print(f"Dirección: {cliente['direccion']}")
        return cliente
    
    return None

def eliminarCliente():
    global registros
    cliente = consultarCliente()
    if cliente:
        print("***Eliminar Cliente***")
        print()
        confirmacion = fnc.getLetra("Esta seguro que desea eliminar este cliente? (s/n): ","S,N")
        if confirmacion == "S":
            fieldnames =  registros[0].keys()
            registros.remove(cliente)
            try:
                with open("cliente.csv","w",encoding="utf-8", newline='') as archivo:                    
                    writer =  csv.DictWriter(archivo, fieldnames=fieldnames, delimiter="|")
                    writer.writeheader()
                    writer.writerows(registros)

            except Exception as e:
                print(f"Error {e}")
            
            print("Cliente eliminado con éxito")

        else:
            print("Operación cancelada.")

    fnc.getLetra("presione S para continuar.","S")

def listarClientes():
    os.system("cls")
    print("***Lista de Clientes***")
    print()
    if os.path.exists("cliente.csv"):
        with open("cliente.csv","r",encoding="utf-8") as archivo:
            reader = csv.DictReader(archivo,delimiter="|")    
            for cliente in reader:
                print(f"ID: {cliente['id']},Nombre: {cliente['nombre']},# Documento: {cliente['documento']}")
    else:
        print("No hay clientes...")

    fnc.getLetra("presione S para continuar.","S")
    return None


