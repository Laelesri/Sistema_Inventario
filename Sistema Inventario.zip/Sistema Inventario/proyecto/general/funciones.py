import datetime
formatoFecha = "%d-%m-%Y"
import re

def validarCedula(cedula):
    # Verificar longitud y que todos sean dígitos
    if len(cedula) != 10 or not cedula.isdigit():
        return False, "Cédula inválida: debe tener 10 dígitos numéricos"

    # Extraer dígitos y coeficientes
    digitos = [int(d) for d in cedula]
    coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2]
    
    # Calcular suma ponderada
    suma = 0
    for i in range(9):
        valor = digitos[i] * coeficientes[i]
        suma += valor if valor < 10 else valor - 9

    # Calcular dígito verificador
    modulo = suma % 10
    digito_calculado = 0 if modulo == 0 else 10 - modulo

    # Verificar dígito calculado con el último dígito de la cédula
    if digito_calculado == digitos[9]:
        return True, "Cédula válida"
    
    # Si no coincide, verificar si es una cédula antigua
    residuo = suma % 10
    digito_calculado_antiguo = 10 - residuo if residuo != 0 else 0
    
    if digito_calculado_antiguo == digitos[9]:
        return True, "Cédula válida (formato antiguo)"
    
    return False, "Cédula inválida"

def getOpcion(mensaje):
    while True:
        try:
            valor = int(input(mensaje))
            return valor
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")

def getLetra(mensaje,opcion):
    while True:
        letra = input(mensaje)
        if len(letra) == 1 and letra.isalpha() and letra.upper() in opcion:
            return letra.upper()
        else:
            print(f"Error: Por favor, ingrese una letra.({opcion})")

def getEntero(mensaje):
    while True:
        try:
            valor = int(input(mensaje))
            return valor
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")

def getFlotante(mensaje):
    while True:
        try:
            valor = float(input(mensaje))
            return valor
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")

def getString(mensaje):
    while True:
        cadena = input(mensaje).strip()
        if cadena and all(char.isalpha() or char.isspace() for char in cadena):
            return cadena
        else:
            print("Ingrese una cadena válida.")

def getFecha(mensaje):
    while True:
        try:
            fechaStr = input(mensaje)
            fecha = datetime.strptime(fechaStr, formatoFecha)
            return fecha
        except ValueError:
            print("Error: Por favor, ingrese una fecha válida.")

def getStringNumerico(mensaje,largo):
    while True:
        cadena = input(mensaje)
        if len(cadena) == largo and cadena.isnumeric():
            return cadena
        else:
            print(f"Ingrese {largo} números.")

def getCorreo(mensaje):
    patron = r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    while True:
        correo = input(mensaje)
        if re.match(patron, correo):
            return correo
        else:
            print("Error: por favor, ingrese una dirección de correo electrónico válida.")
