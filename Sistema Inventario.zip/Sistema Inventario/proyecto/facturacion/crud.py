import os
from general import funciones as fnc
from cliente import crud as c
from producto import crud as p
import datetime
import  csv
facturas = []
impuesto = 0.12  

def existeDocumento(archivo_csv,documento):
    global registros
    if os.path.exists(archivo_csv):
        with open(archivo_csv,"r",encoding="utf-8") as archivo:
            reader = csv.DictReader(archivo,delimiter="|")
            registros = list(reader)

        existe = next((reg for reg in registros if reg["documento"] == documento), None)

        return existe
    else:
        return None
    

def crearFactura():
    archivo_csv = 'factura.csv'
    os.system("cls")
    print("***Creación de Facturación***")
    print()
    
    cliente = c.consultarCliente()
    if not cliente:
        print("No se puede crear la factura sin un cliente.")
        return

    factura = {
        "id": len(facturas) + 1,
        "cliente": cliente,
        "productos": [],
        "fecha": datetime.datetime.now(),
        "subtotal": 0,
        "impuesto": 0,
        "total": 0
    }
    
    while True:
        producto = p.consultarProducto()
        if not producto:
            print("Producto no encontrado. Intente de nuevo.")
            continue
        
        cantidad = fnc.getEntero(f"Ingrese la cantidad de {producto['nombre']}: ")
        if cantidad <= 0:
            print("La cantidad debe ser mayor a 0.")
            continue
        
        total_producto = producto['precio'] * cantidad
        factura['productos'].append({
            "producto": producto,
            "cantidad": cantidad,
            "total": total_producto
        })

        factura['subtotal'] += total_producto
        continuar = fnc.getLetra("¿Desea agregar otro producto? (s/n): ", "S,N")
        if continuar == "N":
            break

    factura['impuesto'] = factura['subtotal'] * impuesto
    factura['total'] = factura['subtotal'] + factura['impuesto']
    
    facturas.append(factura)
    print(f"Factura {factura['id']} creada con éxito. Total: {factura['total']:.2f}")
    fnc.getLetra("Presione S para continuar ...", "S")
    
    try:
        id = 1
        registros = []
        
        if os.path.exists(archivo_csv):
            with open(archivo_csv, "r", encoding="utf-8") as archivo:
                reader = csv.DictReader(archivo, delimiter="|")
                registros = list(reader)
                id = len(registros) + 1
        
        nueva_factura = {
            "id": id,
            "cliente": cliente,
            "productos": factura['productos'],  # Include productos from the created factura
            "fecha": factura['fecha'],
            "subtotal": factura['subtotal'],
            "impuesto": factura['impuesto'],
            "total": factura['total']
        }

        with open(archivo_csv, "a+", encoding="utf-8", newline='') as archivo:
            fieldnames = nueva_factura.keys()
            writer = csv.DictWriter(archivo, fieldnames=fieldnames, delimiter='|')

            if id == 1:
                writer.writeheader()
            writer.writerow(nueva_factura)

        print(f"Factura {cliente} agregado con éxito")
        fnc.getLetra("Presione S para continuar ...", "S")
        return True
    
    except Exception as e:
        fnc.getLetra(f"Error {e}, Presione S para continuar ...", "S")
        return False
    
def consultarFactura():
    os.system("cls")
    print("*** Consulta de Factura ***")
    factura_cliente = fnc.getString("Ingrese el cliente de la factura: ")
    
    for factura in facturas:
        if factura['cliente'] == factura_cliente:
            print(f"Cliente: {factura['cliente']['nombre']}")
            print(f"Fecha: {factura['fecha'].strftime(fnc.formatoFecha)}")
            print("Productos:")
            for item in factura['productos']:
                print(f"- {item['producto']['nombre']} (Cantidad: {item['cantidad']}, Total: {item['total']:.2f})")
            print(f"Subtotal: {factura['subtotal']:.2f}")
            print(f"Impuesto: {factura['impuesto']:.2f}")
            print(f"Total: {factura['total']:.2f}")
            fnc.getLetra("Presione S para continuar ...", "S")
            return

    print("Factura no encontrada.")
    fnc.getLetra("Presione S para continuar ...", "S")
    
    