import os
from general.funciones import *
from facturacion.crud import *

def menu():
    salir = True
    while salir:
        os.system("cls")
        print("***Facturación***")
        print()
        print("1. Crear Factura")
        print("2. Consultar Factura")
        print("3. Eliminar Factura")
        print("4. Generar Reporte de Ventas")
        print("5. Volver al menú principal")
        print()

        opcion = getOpcion("Digite el # de opcion: ")

        if opcion == 1:
            crearFactura()
        elif opcion == 2:
            consultarFactura()
        elif opcion == 3:
            pass
        elif opcion == 4:
            pass
        elif opcion == 5:
            salir = False
        else:
            print("Opción incorrecta.!")

    return True